

var firstName, lastName, favColor;
firstName = prompt('What is your first name');
lastName = prompt('last name?');
favColor = prompt('What is your favorite color?');
alert('His first name is ' + firstName);
alert('full name is ' + firstName + ' ' + lastName + ' and your favorite color is ' + favColor);